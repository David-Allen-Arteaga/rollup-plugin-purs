/// <reference types="vite/client" />
/// <reference types='vite-plugin-svg.ok/client' />
